#include <iostream>
#include <cmath>    
#include <iomanip>   

using namespace std;

int main() {
	
    double roomWidth, roomLength;    
    double tileWidth, tileLength;   
    double tileCost;                 
    double baseCharge;         

    cout << "Enter room width (ft): ";
    cin >> roomWidth;
    cout << "Enter room length (ft): ";
    cin >> roomLength;

    cout << "Enter tile width (in): ";
    cin >> tileWidth;
    cout << "Enter tile length (in): ";
    cin >> tileLength;

    cout << "Enter cost per tile: ";
    cin >> tileCost;
    double roomArea = roomWidth * roomLength;
    double tileArea = (tileWidth / 12.0) * (tileLength / 12.0);
    double rawTilesNeeded = roomArea / tileArea;
    int totalTiles = (int) ceil(rawTilesNeeded * 1.10);
    double tileTotalCost = totalTiles * tileCost;
    double groutWeight = roomArea * 0.13; 
    int groutBags = (int) ceil(groutWeight / 25.0);
    double groutTotalCost = groutBags * 80.0;
    int thinsetBags = (int) ceil(roomArea / 90.0);
    double thinsetTotalCost = thinsetBags * 50.0;
    double totalCost = tileTotalCost + groutTotalCost + thinsetTotalCost;
    double vat = totalCost * 0.125;
    double billAmount = totalCost + vat;

    cout << fixed << setprecision(2);
    cout << "\nDANIEL'S ONE STOP TILE SHOP\n";
    cout << "INVOICE\n\n";
    cout << "ITEM\t\tQTY\tUNIT COST\tSUBTOTAL\n";
    cout << "---------------------------------------------\n";
    cout << "Tiles\t\t" << totalTiles << "\t" << tileCost << "\t\t" << tileTotalCost << "\n";
    cout << "Grout\t\t" << groutBags << "\t80.00\t\t" << groutTotalCost << "\n";
    cout << "Thinset\t\t" << thinsetBags << "\t50.00\t\t" << thinsetTotalCost << "\n\n";

    cout << "Total Cost:\t" << totalCost << endl;
    cout << "VAT (12.5%):\t" << vat << endl;
    cout << "Bill Amount:\t" << billAmount << endl;

    cout << "\nEnter base delivery charge: ";
    cin >> baseCharge;

    cout << "\nDELIVERY RATES\n";
    cout << "Distance\tBase\tSurcharge\tTotal\n";
    cout << "------------------------------------------\n";

    for (int dist = 5; dist <= 50; dist += 5) {
        double surcharge = dist * 4.0;
        double totalDelivery = baseCharge + surcharge;
        cout << dist << " km\t\t" << baseCharge << "\t" << surcharge << "\t\t" << totalDelivery << endl;
    }

    return 0;
}

