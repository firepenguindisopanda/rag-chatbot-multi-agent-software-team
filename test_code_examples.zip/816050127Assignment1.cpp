#include <iostream>
#include <cmath>
using namespace std;

int main() {
	float froom_width, froom_length, iroom_length, iroom_width, iroom_area, tile_width, tile_length, price_tiles, tiles_cost, tile_area; 
	double num_tiles, total_tiles, extra_tiles;
	//variables to calculate the dimensions of the room and tiles as well as the amount of tiles to purchased.
	
	cout << "Enter the length of the room in feet: ";
	cin >> froom_length;
	cout << "Enter the width of the room in feet: ";
	cin >> froom_width;
	cout << "Enter the length of the tile in inches: ";
	cin >> tile_length;
	cout << "Enter the width of the tile in inches: ";
	cin >> tile_width; 
	cout << "Enter the cost of the tile: ";
	cin >> price_tiles;
	//asked the user for the values to complete calculations. 
	
	iroom_length = froom_length * 12;
	iroom_width = froom_width * 12;
	//changed the measurements of the room from feet to inches to calculate the area of the room.
	iroom_area = iroom_length * iroom_width;
	//calculation of the room in inches.
	
	tile_area = tile_length * tile_width; 
	//calulation of the area of a tile.
	
	num_tiles = iroom_area/tile_area;
	extra_tiles = num_tiles * 0.1;
	total_tiles = num_tiles + extra_tiles;
	//calculations to find the number of tiles needed for the room as well as the additional 10% extra.
	
	tiles_cost = total_tiles * price_tiles;
	//the cost of the amount of tiles that the user must purchase. 
	
	float froom_area, amount_grout, cost_grout, cost_thinset;
	double total_grout, total_thinset;
	//variables to calculate the amount of grout and thinset needed to tile the room and the cost of the grout and thinset. 
	
	froom_area = froom_length * froom_width;
	//calculation of the room in feet.
	
	amount_grout = froom_area * 0.13;
	total_grout = amount_grout/25;
	cost_grout = ceil(total_grout) * 80;
	//calculations to find the number of bags of grout needed to tile the room and the cost of the total number of bags. 
	
	total_thinset = froom_area/50;
	cost_thinset = ceil(total_thinset) * 50;
	//calculations to find the number of bags of thinset to tile the room and the cost of the total number of bags. 
	
	float price, vat, total;
	//variables to calculate the VAT of the overall total. 
	
	price = tiles_cost + cost_grout + cost_thinset; 
	vat = price * 0.125;
	total = price + vat;
	//calculations of the overall price, the amount of VAT on the overall price and the total of overall price and VAT.
	
	cout << "|---------------------------------------------------------------|" << endl;
	cout << "|                 DANIEL'S ONE STOP TILE SHOP                   |" << endl;
	cout << "|                          INVOICE                              |" << endl;
	cout << "|ITEM\t\t\t\tQTY\tUNIT COST\tSUBTOTAL|" << endl;
	cout << "|-------------\t\t\t-----\t----------\t--------|" << endl;
	cout << "| Tiles\t\t\t\t" << ceil(total_tiles) << "\t" << price_tiles << "\t\t" << tiles_cost << "\t|" << endl;
	cout << "| Grout\t\t\t\t" << ceil(total_grout) << "\t80\t\t" << cost_grout << "\t|" << endl;	
	cout << "| Thinset\t\t\t" << ceil(total_thinset) << "\t50\t\t" << cost_thinset << "\t|" << endl;
	cout << "|                                                               |" << endl;
	cout << "|\t\t\t\t\tTotal Cost:\t" << price << "\t|" << endl;
	cout << "|\t\t\t\t\tVAT (12.5%):\t" << vat << "\t|" << endl;
	cout << "|\t\t\t\t\tBill Amount:\t" << total << "\t|" << endl;
	cout << "|                                                               |" << endl; 
	cout << "|   WE ACCEPT CASH, LINX, OR CREDIT CARD FOR YOUR CONVENIENCE   |" << endl;
	cout << "|---------------------------------------------------------------|" << endl;
	cout << endl; 
	//outputs to display the invoice. 
	
	float distance, base_charge, subcharge, delivery_total;	
	//variables to calculate the delivery charge. 
	
	cout << "Enter the base charge:";
	cin >> base_charge;
	cout << endl;
	//asked the user for the base charge of their delivery. 
	
	cout << "					  Delivery Rates" << endl; 
	cout << "Distance		Base Charge		Subcharge		Total" << endl;
	//heading of the tables of delivery rates. 
	
	for (distance = 5; distance <= 50; distance = distance +5) //for loop to display the contents of the delivery rates table. 
	{
		subcharge = distance * 4;
		delivery_total = base_charge + subcharge; 
		//calculations to find the subcharge and the total amount of delivery fee that the user must pay.
		
		cout << distance << "			" << base_charge << "			" << subcharge << "			"  << delivery_total << endl;
		//output to display the variables under each header. 
	}
	
	return 0;
}