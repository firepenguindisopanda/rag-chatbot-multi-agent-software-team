#include <iostream>
#include <cmath>
using namespace std;

int main(){
	//variables:
	int numTiles, extraTiles, totalNumTiles, numGrout, numThinset;
	double roomWidth, roomLength, tileWidth, tileLength, roomArea, tileArea, tileCost, groutWeight, groutCost, thinsetCost;
	double netCost, totalCost, totalTileCost, VAT;
	//constants:
	const double groutPerSqrft = 0.13;
	const double groutWeightPerBag = 25.0;
	const double groutCostPerBag = 80.0;
	const double thinsetCoveragePerBag = 90;
	const double thinsetWeightPerBag = 50.0;
	const double thinsetCostPerBag = 50.0;
	const double vatRate = 0.125;
	
	//Code
	cout << "------------------Welcome to Daniel's One Stop Tile Shop!-----------------------" << endl << endl;
	cout << "Please enter Room Width in feet: ";
	cin >> roomWidth;
	
	cout << "Please enter Room Length in feet: ";
	cin >> roomLength;
	
	cout << "Please enter Tile Width in inches: ";
	cin >> tileWidth;
	
	cout << "Please enter Tile length in inches: ";
	cin >> tileLength;
	
	cout << "Please enter cost per tile:$ "; 
	cin >> tileCost;
	
	cout << "                                                                          " << endl;
//----------------------------------------------------------------------------------------------//
	roomArea = roomWidth * roomLength;
	tileArea = (tileWidth/12.0) * (tileLength/12.0);  //converting inches into feet
	
	numTiles = roomArea/tileArea;
	extraTiles = numTiles * 0.10;
	totalNumTiles = extraTiles + numTiles;
	totalTileCost = totalNumTiles * tileCost;
	
	groutWeight = roomArea * 0.13; //amount of grout needed in pounds
	numGrout = ceil(groutWeight/25.0);
	groutCost = numGrout * 80.0;
	
	numThinset = ceil(roomArea/90.0); //amount of thinset needed
	thinsetCost = numThinset * 50.0;
	
	netCost = totalTileCost + groutCost + thinsetCost;
	
	VAT = netCost * 0.125; //VAT = 12.5%
	
	totalCost = netCost + VAT;
	
	//Invoice
	
	cout << "Room area: " << roomArea << " sqr ft" << endl;
	cout << "Tile area: " << tileArea << " sqr ft" << endl  << endl << endl;
	
	
	cout << "                 DANIEL'S ONE STOP TILE SHOP!                " << endl;
	cout << "-------------------------------------------------------------" << endl;
    cout << "                         INVOICE                             " << endl;
    cout << "-------------------------------------------------------------" << endl;
    cout << "Item\t\t\tQuantity\tUnit Price\tSubTotal                          " << endl;
    cout << "-------------------------------------------------------------" << endl;
    cout << "Tiles needed\t\t" << totalNumTiles << "\t\t$" << totalTileCost << "\t\t$" << totalTileCost << endl;
    cout << "Grout Bags needed\t" << numGrout << "\t\t$80.00\t\t$" << groutCost << endl;
    cout << "Thinset Bags needed\t" << numThinset << "\t\t$50.00\t\t$" << thinsetCost << endl;
    cout << "-------------------------------------------------------------" << endl;
    cout << "Subtotal:\t\t\t\t\t$" << netCost << endl;
    cout << "VAT (12.5%):\t\t\t\t\t$" << VAT << endl;
    cout << "GRAND TOTAL:\t\t\t\t\t$" << totalCost << endl;
    cout << "-------------------------------------------------------------" << endl << endl;
    

	
	
	
	
	
	
	
	//----------------PART C: DELIVERY---------------------------//
	
	
	int distance;
	double baseCharge, surCharge, totalDelivery;
	
	cout << "Enter base delivery charge:$ ";
    cin >> baseCharge;
	
	
	cout << "----------------DELIVERY RATES---------------------------" << endl;
	cout << "---------------------------------------------------------" << endl;
	cout << "Distance\tBase Charge\tSurCharge\tTotal" << endl;
	cout << "---------------------------------------------------------" << endl;
	
	
	for (distance = 5; distance <= 50; distance = distance + 5 ) {
		surCharge = distance * 4.0;
		totalDelivery = baseCharge + surCharge;
		
		 cout << distance << " km\t\t$" << baseCharge << "\t\t$" << surCharge << "\t\t$" << totalDelivery << endl;
	}
	
	
return 0;
}
